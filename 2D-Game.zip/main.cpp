
#include "Game.h"
#include "Object.h"
using namespace std;
int Game::round = 0;
int main() {
    Game game;
    game.startGame();



    return 0;
}
